from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
from pathlib import Path

import pytest
from PIL import Image, ImageDraw

from automation.media import MediaProcessor


@pytest.mark.asyncio
async def test_arabic_template_and_ocr(settings, account: dict, tmp_path: Path) -> None:
    if not shutil.which("tesseract"):
        pytest.skip("Tesseract unavailable")
    languages = await asyncio.to_thread(subprocess.check_output, ["tesseract", "--list-langs"], text=True)
    if "ara" not in languages.splitlines():
        pytest.skip("Arabic Tesseract data unavailable")

    processor = MediaProcessor(settings)
    output = tmp_path / "arabic-template.png"
    processor.render_text_template("جدول محاضرات الجامعة\nالأحد: رياضيات — القاعة ٢٤", account, output)
    with Image.open(output) as image:
        assert image.size == (1080, 1350)
        assert image.mode == "RGB"

    # لوحة OCR بسيطة تقلل تأثير الزخارف على دقة الاختبار.
    source = tmp_path / "ocr-source.png"
    image = Image.new("RGB", (1400, 360), "white")
    draw = ImageDraw.Draw(image)
    font = processor._font(100, bold=True)
    text, kwargs = processor._prepare_text("جدول محاضرات الجامعة")
    draw.text((1320, 170), text, font=font, fill="black", anchor="rm", **kwargs)
    image.save(source)
    extracted = await processor.ocr_image(source)
    assert extracted.strip()
    assert "جامع" in extracted or "محاضر" in extracted


@pytest.mark.asyncio
async def test_overlay_and_video_processing(settings, account: dict, tmp_path: Path) -> None:
    processor = MediaProcessor(settings)
    account["settings"] = {
        "template": {
            "mode": "overlay",
            "redactions": [{"x": 0.0, "y": 0.0, "w": 0.4, "h": 0.2}],
            "video_color_tweak": True,
            "watermark_opacity": 0.5,
        }
    }
    source = tmp_path / "source.png"
    Image.new("RGB", (640, 480), "#2870b0").save(source)
    output = tmp_path / "overlay.png"
    await processor.process_image(source, account, output)
    with Image.open(output) as result:
        assert result.size == (640, 480)

    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        pytest.skip("FFmpeg unavailable")
    video = tmp_path / "source.mp4"
    await asyncio.to_thread(subprocess.run, [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-f", "lavfi", "-i", "testsrc2=size=320x240:rate=12",
        "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100",
        "-t", "0.6", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(video),
    ], check=True, timeout=60)
    processed = tmp_path / "processed.mp4"
    await processor.process_video(video, account, processed)
    probe = json.loads(await asyncio.to_thread(subprocess.check_output, [
        "ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name",
        "-of", "json", str(processed),
    ], text=True))
    streams = probe["streams"]
    assert any(item["codec_type"] == "video" and item["codec_name"] == "h264" for item in streams)
    assert any(item["codec_type"] == "audio" and item["codec_name"] == "aac" for item in streams)


@pytest.mark.asyncio
async def test_reused_video_keeps_full_narration(settings, db, account: dict, tmp_path: Path, monkeypatch) -> None:
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        pytest.skip("FFmpeg unavailable")
    from automation.studio import StudioService

    service = StudioService(settings, db)
    asset_dir = settings.data_dir / "studio-assets" / account["id"]
    asset_dir.mkdir(parents=True, exist_ok=True)
    source = asset_dir / "short-owned.mp4"
    narration = tmp_path / "long-narration.wav"
    await asyncio.to_thread(subprocess.run, [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-f", "lavfi", "-i", "testsrc2=size=360x640:rate=12", "-t", "1",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", str(source),
    ], check=True, timeout=60)
    await asyncio.to_thread(subprocess.run, [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=24000", "-t", "4", str(narration),
    ], check=True, timeout=60)
    asset = service.store.create_asset(account["id"], "video", str(source.relative_to(settings.data_dir)), source.name)
    project = await service.create_project({
        "account_id": account["id"], "brief": "خدمة طلابية تجريبية", "kind": "student_promo",
        "source_mode": "reuse", "output_format": "video", "source_asset_id": asset["id"],
        "rights_confirmed": True, "use_ai": False,
    })

    async def fake_speech(text: str, voice: str, output_dir: Path):
        target = output_dir / "narration.wav"
        shutil.copy(narration, target)
        return target, "test-voice", ""

    monkeypatch.setattr(service, "_speech", fake_speech)
    output_dir = settings.data_dir / "studio" / project["id"]
    output_dir.mkdir(parents=True, exist_ok=True)
    result = await service._render_reuse(project, account, output_dir)
    output = settings.data_dir / result["output_path"]
    metadata = await service.media.probe(output)
    duration = float(metadata["format"]["duration"])
    streams = metadata["streams"]
    assert duration >= 4.5, "يجب أن يمتد الفيديو القصير ليستوعب التعليق الصوتي كاملًا"
    assert any(item["codec_type"] == "video" and item.get("width") == 720 and item.get("height") == 1280 for item in streams)
    assert any(item.get("codec_type") == "audio" for item in streams)
    assert result["voice_provider"] == "test-voice"
