from __future__ import annotations

import json
import tarfile
from pathlib import Path

import pytest

from automation.browser import (
    BrowserError,
    import_storage_state,
    netscape_cookies,
    playwright_proxy,
)
from automation.config import mask_proxy
from automation.maintenance import cleanup_files, create_backup
from automation.studio_db import StudioStore


def test_proxy_parsing_and_masking() -> None:
    parsed = playwright_proxy("socks5://user:p%40ss@example.com:1080")
    assert parsed == {"server": "socks5://example.com:1080", "username": "user", "password": "p@ss"}
    assert mask_proxy("socks5://user:p%40ss@example.com:1080") == "socks5://user:***@example.com:1080"
    with pytest.raises(BrowserError):
        playwright_proxy("file:///tmp/socket")


def test_import_storage_state_and_netscape_conversion(settings, account: dict) -> None:
    state = import_storage_state(settings, account, [{
        "name": "session", "value": "secret", "domain": ".x.com", "path": "/",
        "expires": -1, "httpOnly": True, "secure": True, "sameSite": "Lax",
    }])
    saved = json.loads(state.read_text(encoding="utf-8"))
    assert saved["cookies"][0]["name"] == "session"
    assert saved["origins"] == []
    converted = netscape_cookies(settings, account)
    text = converted.read_text(encoding="utf-8")
    assert "#HttpOnly_.x.com" in text
    assert "session\tsecret" in text


def test_backup_excludes_key_media_and_temporary_cookies(settings, db, account: dict) -> None:
    account_dir = settings.data_dir / "accounts" / account["id"]
    (account_dir / "assets").mkdir(parents=True, exist_ok=True)
    (account_dir / "media" / "post").mkdir(parents=True, exist_ok=True)
    import_storage_state(settings, account, [{
        "name": "session", "value": "secret", "domain": ".x.com",
    }])
    (account_dir / "assets" / "logo.png").write_bytes(b"logo")
    (account_dir / "media" / "post" / "video.mp4").write_bytes(b"media")
    netscape_cookies(settings, account)
    (settings.data_dir / ".env").write_text("AI_API_KEY=do-not-backup", encoding="utf-8")
    (settings.data_dir / "ai_providers.json").write_text('[{"api_key":"do-not-backup"}]', encoding="utf-8")
    studio_output = settings.data_dir / "studio" / "example" / "vertical.mp4"
    studio_output.parent.mkdir(parents=True)
    studio_output.write_bytes(b"rendered")
    studio_asset = settings.data_dir / "studio-assets" / account["id"] / "source.mp4"
    studio_asset.parent.mkdir(parents=True)
    studio_asset.write_bytes(b"owned-source")

    backup = create_backup(settings, db)
    with tarfile.open(backup, "r:gz") as archive:
        names = archive.getnames()
        manifest = json.loads(archive.extractfile("manifest.json").read().decode("utf-8"))
    assert "bot_memory.db" in names
    assert "manifest.json" in names
    assert f"accounts/{account['id']}/session-x.json" in names
    assert f"accounts/{account['id']}/assets/logo.png" in names
    assert "config/selectors.yaml" in names
    assert not any("media" in Path(name).parts for name in names)
    assert not any(Path(name).name.startswith("cookies-") for name in names)
    assert not any(Path(name).name == ".env" for name in names)
    assert "studio/example/vertical.mp4" in names
    assert f"studio-assets/{account['id']}/source.mp4" in names
    assert not any(Path(name).name == "ai_providers.json" for name in names)
    assert "AI_API_KEY" in manifest["excludes"]
    assert "ai_providers.json" in manifest["excludes"]


def test_studio_cleanup_removes_only_terminal_projects_and_orphan_assets(settings, db, account: dict) -> None:
    from datetime import UTC, datetime, timedelta

    store = StudioStore(settings.database_path)
    old = (datetime.now(UTC) - timedelta(days=120)).isoformat(timespec="seconds")
    published = store.create_project({"account_id": account["id"], "title": "قديم", "status": "published"})
    ready = store.create_project({"account_id": account["id"], "title": "محفوظ", "status": "ready"})
    orphan = store.create_asset(account["id"], "video", "studio-assets/orphan.mp4", "orphan.mp4")
    kept = store.create_asset(account["id"], "video", "studio-assets/kept.mp4", "kept.mp4")
    store.update_project(ready["id"], {"source_asset_id": kept["id"]})
    for asset, name in ((orphan, "orphan.mp4"), (kept, "kept.mp4")):
        path = settings.data_dir / asset["path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(name.encode())
    folder = settings.data_dir / "studio" / published["id"]
    folder.mkdir(parents=True)
    (folder / "vertical.mp4").write_bytes(b"old-render")
    with db.transaction() as conn:
        conn.execute("UPDATE studio_projects SET updated_at=?", (old,))
        conn.execute("UPDATE studio_assets SET created_at=?", (old,))

    result = cleanup_files(settings, 90, db)
    assert result["studio"]["projects_removed"] == 1
    assert result["studio"]["assets_removed"] == 1
    assert store.get_project(published["id"]) is None
    assert store.get_project(ready["id"]) is not None
    assert store.get_asset(orphan["id"]) is None
    assert store.get_asset(kept["id"]) is not None
    assert not folder.exists()
    assert (settings.data_dir / kept["path"]).exists()
